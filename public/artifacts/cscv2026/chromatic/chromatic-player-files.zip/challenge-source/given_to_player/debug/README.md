# Chromatic debug harness

Dev-only overlay on `given_to_player/docker-compose.yml`.

```bash
./debug/dbg up --build     # first run
./debug/dbg urls           # port map
./debug/dbg logs edge      # live cache HIT/MISS per request
```

`web/` now lives inside the bundle, so the base compose builds as shipped. The
overlay only adds observability and access; it never changes cache semantics.

## Port map

| Reach | Address | Skips |
|---|---|---|
| app through nginx | `localhost:8080` | nothing, this is the real path |
| web direct | `localhost:3000` | the cache |
| renderer direct | `localhost:5000` | the cache and the admin cookie |
| bot direct | `localhost:3001` | `/api/report`'s 4s cooldown |

Inspectors bind to `127.0.0.1` only, since an open Node inspector is remote code
execution: web `9229`, renderer `9230`, worker `9231`, bot `9232`.

## What each piece buys you

**Cache visibility.** `nginx.debug.conf` is byte-identical to the shipped config
for everything affecting caching, and adds an access log plus two headers:

```
X-Cache-Status: MISS | HIT
X-Cache-Key:    http|GET|<what the map normalised to>
```

`$representation_id` collapses any `/api/*` URL carrying `workspace=<24 hex>`
onto one key, so two different paths share a cache entry.

```bash
./debug/dbg key '/api/workspaces/manifest?workspace=aaaaaaaaaaaaaaaaaaaaaaaa'
./debug/dbg cache-ls
./debug/dbg cache-flush    # between attempts, or you debug a stale entry
```

Cache lifetime stays at the shipped values on purpose. `cache-flush` is the reset
button, not a shorter TTL.

**libmagic oracle.** `dbg mime <file>` runs `file --brief --mime-type` on a local
file inside the web image, so you see exactly what `/api/media`'s upload check
will decide without going through HTTP.

**Readable frontend.** `web/Dockerfile.debug` mirrors the real Dockerfile but
builds Angular with `--optimization=false --source-map=true
--output-hashing=none`, so `main.ts`, `legacy-blocks.ts` and `board-compat.js`
are steppable instead of one minified blob.

**The worker, in isolation.** `app.js` spawns `worker.js` as a child and swallows
its failures into a generic 422. `dbg worker` runs it standalone under
`--inspect-brk` with a job on stdin, so you can breakpoint `mergeCatalog` and
watch a `theme` key land in the EJS options object. `dbg compose` does the same
over HTTP, `dbg preview` runs the full admin path with the cookie pulled from
the container.

**Bot.** `bot.js` forwards page console output, so `dbg logs bot` shows
`[review] log: ...` and any CSP violation from the visited page. Uncomment
`DEBUG: "pw:api"` in the overlay for Playwright tracing. `dbg visit <id>` queues
a visit directly, bypassing the per-IP cooldown.

Note `page.on('pageerror')` is not wired up, so a script that throws in the
bot's browser fails silently.

## Editing code

`server.js`, `app.js`, `worker.js`, `bot.js` and `static/` are bind-mounted, so
host edits land in the container. Restart to pick them up:

```bash
./debug/dbg reload renderer
```

`reload` recreates rather than restarts: editors that save by writing a temp file
and renaming swap the inode, silently detaching a single-file bind mount.

Frontend changes need `./debug/dbg up --build`.

## Attaching a debugger

Open `given_to_player/` as the VS Code folder, then "Run and Debug".
`.vscode/launch.json` has attach configs for all four inspectors plus an
"attach: all services" compound. Otherwise use `chrome://inspect` and add
`127.0.0.1:9229` through `:9232`.
