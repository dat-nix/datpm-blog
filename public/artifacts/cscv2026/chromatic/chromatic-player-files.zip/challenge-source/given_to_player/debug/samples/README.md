Job bodies for `dbg compose` / `dbg worker` / `dbg preview`.

All three take the same shape, `{"theme": {...}, "title": "..."}`:

  dbg compose samples/compose-job.json   # renderer:5000, no auth, no cache
  dbg worker  samples/compose-job.json   # worker.js alone, paused for a debugger
  dbg preview samples/compose-job.json   # full path through web as the admin

`theme` is merged into the EJS options object by mergeCatalog() in worker.js,
so this is the file to edit when probing how a key lands in those options.
